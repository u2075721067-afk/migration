# MOVA Automation Engine — Starter (MVP)

Мінімальний каркас для старту розробки MVP:
- Go executor + HTTP API
- JSON Schema для envelope та базових дій
- OpenAPI, Dockerfile, docker-compose
- Простий приклад

## Швидкий старт
```bash
# 1) Побудувати та запустити
make build && ./bin/mova-api
# або
docker compose up --build

# 2) Перевірка
curl -s http://localhost:8080/v1/schemas/envelope | head

# 3) Запуск прикладу
curl -s 'http://localhost:8080/v1/execute?wait=true' -H 'content-type: application/json' -d @examples/hello.json | jq
```

## Структура
- `cmd/api` — HTTP API
- `internal/engine` — Envelope/Runner/Store
- `schemas/` — JSON Schemas
- `api/openapi.yaml` — контракт
- `config/allowlist.yaml` — дозволені домени для http_fetch (у стартері не реалізований)
- `examples/` — приклади

## Доробити
- Реальні валідатори за JSON Schema
- Повні реалізації дій (`http_fetch`, `if`, `repeat`, тощо)
- Маскування секретів у логах
- SDK/CLI/Console
