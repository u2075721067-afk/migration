
# k6 Smoke Report (Template)

> Автоматично генерується у CI (див. workflow `k6 Smoke Test`). Цей файл можна використовувати локально:
>
> ```bash
> k6 run --summary-export=reports/k6_summary.json k6_mova_smoke.js
> ./tools/k6_to_md.sh reports/k6_summary.json > reports/k6_smoke_report.md
> ```

## Summary
- VUs: _підставляється_
- Duration: _підставляється_
- p95 http_req_duration: _підставляється_
- Requests: _підставляється_
- Failures: _підставляється_

## Thresholds
- http_req_duration p95 < 500 ms — _OK/FAIL_

## Raw summary (fragment)
```json
{ ... }
```
