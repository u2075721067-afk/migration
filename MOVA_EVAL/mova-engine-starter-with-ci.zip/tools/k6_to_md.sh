
#!/usr/bin/env bash
# Usage: ./tools/k6_to_md.sh reports/k6_summary.json
set -euo pipefail
FILE="${1:-reports/k6_summary.json}"
jq -r '
  "# k6 Smoke Report\n\n" +
  "## Summary\n" +
  "- VUs: 100\n" +
  "- Duration: 60s\n" +
  "- p95 http_req_duration: \(.metrics.http_req_duration.percentiles["p(95)"]) ms\n" +
  "- Requests: \(.metrics.http_reqs.count)\n" +
  "- Failures: \(.metrics.checks.fails)\n\n" +
  "## Thresholds\n" +
  "- http_req_duration p95 < 500 ms — \(.metrics.http_req_duration.thresholds["p(95)<500"].ok)\n\n" +
  "## Raw summary (fragment)\n```json\n" +
  (.metrics | {http_req_duration, http_reqs, data_sent, data_received} | tojson) +
  "\n```\n"
' "$FILE"
