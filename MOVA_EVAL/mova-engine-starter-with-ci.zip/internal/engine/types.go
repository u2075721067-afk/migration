package engine

type Envelope struct {
	MovaVersion string                 `json:"mova_version"`
	Intent      string                 `json:"intent"`
	Payload     map[string]any         `json:"payload"`
	Actions     []ActionSpec           `json:"action"`
	Context     map[string]any         `json:"context,omitempty"`
	Meta        map[string]any         `json:"meta,omitempty"`
}

type ActionSpec struct {
	Type   string         `json:"type"`
	Params map[string]any `json:"params,omitempty"`
}
