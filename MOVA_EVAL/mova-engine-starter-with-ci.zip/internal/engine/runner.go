package engine

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"time"
)

type RunStatus string

const (
	StatusPending RunStatus = "pending"
	StatusRunning RunStatus = "running"
	StatusSuccess RunStatus = "success"
	StatusError   RunStatus = "error"
)

type Run struct {
	ID        string         `json:"id"`
	Status    RunStatus      `json:"status"`
	Result    any            `json:"result,omitempty"`
	Error     *RunError      `json:"error,omitempty"`
	Logs      []string       `json:"logs"`
	Envelope  Envelope       `json:"envelope"`
	StartedAt time.Time      `json:"started_at"`
	EndedAt   *time.Time     `json:"ended_at,omitempty"`
}

type RunError struct {
	Type    string `json:"type"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

type RunStore struct { runs map[string]*Run }

func NewRunStore() *RunStore { return &RunStore{runs: map[string]*Run{}} }

func (s *RunStore) NewRun(env Envelope) *Run {
	id := fmt.Sprintf("run_%d", time.Now().UnixNano()+int64(rand.Intn(999)))
	r := &Run{ID: id, Status: StatusPending, Envelope: env, Logs: []string{}}
	s.runs[id] = r
	return r
}

func (s *RunStore) Get(id string) (*Run, bool) {
	r, ok := s.runs[id]
	return r, ok
}

func logf(r *Run, format string, args ...any) {
	line := fmt.Sprintf(format, args...)
	r.Logs = append(r.Logs, time.Now().Format(time.RFC3339Nano)+" " + line)
}

func Execute(r *Run) {
	r.Status = StatusRunning
	r.StartedAt = time.Now()
	defer func() {
		ended := time.Now()
		r.EndedAt = &ended
	}()

	ctx := map[string]any{}
	last := any(nil)

	for i, a := range r.Envelope.Actions {
		logf(r, "step %d: %s", i+1, a.Type)
		switch a.Type {
		case "print", "log":
			data, _ := json.Marshal(a.Params["value"]) // allow any value
			logf(r, "print: %s", string(data))
			last = a.Params["value"]
		case "set":
			k, _ := a.Params["var"].(string)
			ctx[k] = a.Params["value"]
			last = ctx[k]
		case "sleep":
			dur := time.Duration(0)
			if v, ok := a.Params["seconds"].(float64); ok {
				dur = time.Duration(v*1000) * time.Millisecond
			}
			time.Sleep(dur)
			last = map[string]any{"slept_seconds": a.Params["seconds"]}
		default:
			r.Status = StatusError
			r.Error = &RunError{Type: "unsupported_action", Code: a.Type, Message: "Action not implemented in starter"}
			logf(r, "error: unsupported action %q", a.Type)
			return
		}
	}
	r.Result = last
	r.Status = StatusSuccess
	logf(r, "done")
}
