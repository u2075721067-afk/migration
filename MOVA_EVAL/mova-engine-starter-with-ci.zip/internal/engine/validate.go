package engine

func ValidateEnvelope(env Envelope) []string {
	errs := []string{}
	if env.MovaVersion == "" {
		errs = append(errs, "mova_version is required")
	}
	if env.Intent == "" {
		errs = append(errs, "intent is required")
	}
	if len(env.Actions) == 0 {
		errs = append(errs, "action[] is required (non-empty)")
	}
	return errs
}
