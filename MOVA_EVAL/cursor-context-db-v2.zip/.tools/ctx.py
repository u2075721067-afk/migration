
#!/usr/bin/env python3
# Cursor Context DB (SQLite) — minimal helper
# Commands:
#   python .tools/ctx.py save --title "..." --text "..." [--tags ...] [--json payload.json]
#   python .tools/ctx.py last --limit 20
#   python .tools/ctx.py show --id 3 --format text|json
#   python .tools/ctx.py export --id 3 --out ctx.txt

import argparse, json, os, sqlite3, sys
from pathlib import Path

DEFAULT_DB = os.environ.get("CTX_DB_PATH", "state/.cursor_ctx.db")

def connect(db_path: str):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init(db_path: str):
    schema = Path("schema.sql").read_text(encoding="utf-8")
    conn = connect(db_path)
    conn.executescript(schema)
    conn.commit()
    conn.close()

def cmd_save(args):
    conn = connect(args.db)
    context_json = None
    if args.json:
        context_json = Path(args.json).read_text(encoding="utf-8")
        json.loads(context_json)
    conn.execute(
        "INSERT INTO snapshots (title, summary, tags, context_text, context_json, source, author) VALUES (?,?,?,?,?,?,?)",
        (args.title, args.summary, args.tags, args.text, context_json, "cursor", args.author)
    )
    conn.commit()
    rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    print(rid)

def cmd_last(args):
    conn = connect(args.db)
    rows = [dict(r) for r in conn.execute(
        "SELECT id, created_at, title, tags, substr(summary,1,120) AS summary FROM snapshots ORDER BY id DESC LIMIT ?",
        (args.limit,)
    ).fetchall()]
    conn.close()
    print(json.dumps(rows, ensure_ascii=False, indent=2))

def cmd_show(args):
    conn = connect(args.db)
    row = conn.execute("SELECT * FROM snapshots WHERE id = ?", (args.id,)).fetchone()
    conn.close()
    if not row:
        print("Not found", file=sys.stderr); sys.exit(1)
    if args.format == "json":
        print(json.dumps(dict(row), ensure_ascii=False, indent=2))
    else:
        print((row["context_text"] or "").strip())

def cmd_export(args):
    conn = connect(args.db)
    row = conn.execute("SELECT context_text FROM snapshots WHERE id = ?", (args.id,)).fetchone()
    conn.close()
    if not row or row["context_text"] is None:
        print("Not found or empty", file=sys.stderr); sys.exit(1)
    Path(args.out).write_text(row["context_text"], encoding="utf-8")
    print(f"Wrote {args.out}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", default=DEFAULT_DB, help="Path to SQLite DB (default: state/.cursor_ctx.db)")
    sp = p.add_subparsers(dest="cmd", required=True)

    s_init = sp.add_parser("init", help="(re)create schema from schema.sql")
    s_init.set_defaults(func=lambda a: init(a.db))

    s_save = sp.add_parser("save", help="Save a snapshot (raw text + optional JSON)")
    s_save.add_argument("--title", required=True)
    s_save.add_argument("--summary", default="")
    s_save.add_argument("--tags", default="")
    s_save.add_argument("--text", default="")
    s_save.add_argument("--json", default=None, help="Path to JSON payload (optional)")
    s_save.add_argument("--author", default="")
    s_save.set_defaults(func=cmd_save)

    s_last = sp.add_parser("last", help="List last N snapshots")
    s_last.add_argument("--limit", type=int, default=20)
    s_last.set_defaults(func=cmd_last)

    s_show = sp.add_parser("show", help="Print snapshot content")
    s_show.add_argument("--id", type=int, required=True)
    s_show.add_argument("--format", choices=["text","json"], default="text")
    s_show.set_defaults(func=cmd_show)

    s_export = sp.add_parser("export", help="Export context_text to file")
    s_export.add_argument("--id", type=int, required=True)
    s_export.add_argument("--out", required=True)
    s_export.set_defaults(func=cmd_export)

    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
