import json, urllib.request

class MovaClient:
    def __init__(self, base_url: str = "http://localhost:8080"):
        self.base_url = base_url.rstrip("/")
    def validate(self, envelope: dict) -> dict:
        req = urllib.request.Request(self.base_url + "/v1/validate", data=json.dumps(envelope).encode("utf-8"), headers={"content-type":"application/json"})
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode("utf-8"))
    def execute(self, envelope: dict, wait: bool = True) -> dict:
        url = f"{self.base_url}/v1/execute?wait={'true' if wait else 'false'}"
        req = urllib.request.Request(url, data=json.dumps(envelope).encode("utf-8"), headers={"content-type":"application/json"})
        with urllib.request.urlopen(req) as r:
            return json.loads(r.read().decode("utf-8"))
