export class MovedClient {
  constructor(private baseUrl = "http://localhost:8080") {}
  async validate(envelope: any) {
    const res = await fetch(this.baseUrl + "/v1/validate", { method: "POST", headers: {"content-type":"application/json"}, body: JSON.stringify(envelope)});
    return res.json();
  }
  async execute(envelope: any, wait = true) {
    const res = await fetch(this.baseUrl + "/v1/execute?wait="+String(wait), { method: "POST", headers: {"content-type":"application/json"}, body: JSON.stringify(envelope)});
    return res.json();
  }
}
