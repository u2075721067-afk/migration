# QUICKSTART

1) Встановіть Go 1.22+
2) `make build && ./bin/mova-api`
3) `curl -s http://localhost:8080/v1/schemas/envelope`
4) `curl -s 'http://localhost:8080/v1/execute?wait=true' -H 'content-type: application/json' -d @examples/hello.json | jq`

Далі: доповніть дії, підключіть реальну валідацію за JSON Schema та додайте SDK/CLI.
