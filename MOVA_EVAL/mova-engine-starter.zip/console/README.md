# Console placeholder (Next.js app to be added)
