package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
	"github.com/example/mova-engine/internal/engine"
)

func main() {
	// Simple in-memory run store (demo)
	runStore := engine.NewRunStore()

	// Allow-list init
	allowListPath := os.Getenv("MOVA_ALLOWLIST_FILE")
	if allowListPath == "" {
		allowListPath = "./config/allowlist.yaml"
	}
	_ = allowListPath // TODO: load allow-list

	r := mux.NewRouter()

	r.HandleFunc("/v1/validate", func(w http.ResponseWriter, r *http.Request) {
		var env engine.Envelope
		if err := json.NewDecoder(r.Body).Decode(&env); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"valid": false, "errors": []string{err.Error()}})
			return
		}
		errs := engine.ValidateEnvelope(env)
		writeJSON(w, http.StatusOK, map[string]any{"valid": len(errs) == 0, "errors": errs})
	}).Methods(http.MethodPost)

	r.HandleFunc("/v1/execute", func(w http.ResponseWriter, r *http.Request) {
		var env engine.Envelope
		if err := json.NewDecoder(r.Body).Decode(&env); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
			return
		}
		wait := r.URL.Query().Get("wait") == "true"
		run := runStore.NewRun(env)
		go engine.Execute(run) // fire-and-forget
		if wait {
			for run.Status == engine.StatusPending || run.Status == engine.StatusRunning {
				time.Sleep(10 * time.Millisecond)
			}
			writeJSON(w, http.StatusOK, run)
			return
		}
		writeJSON(w, http.StatusAccepted, map[string]any{"run_id": run.ID, "status": run.Status})
	}).Methods(http.MethodPost)

	r.HandleFunc("/v1/runs/{id}", func(w http.ResponseWriter, r *http.Request) {
		id := mux.Vars(r)["id"]
		run, ok := runStore.Get(id)
		if !ok {
			writeJSON(w, http.StatusNotFound, map[string]any{"error": "not found"})
			return
		}
		writeJSON(w, http.StatusOK, run)
	}).Methods(http.MethodGet)

	r.HandleFunc("/v1/runs/{id}/logs", func(w http.ResponseWriter, r *http.Request) {
		id := mux.Vars(r)["id"]
		run, ok := runStore.Get(id)
		if !ok {
			w.WriteHeader(http.StatusNotFound)
			w.Write([]byte("not found"))
			return
		}
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		for _, line := range run.Logs {
			w.Write([]byte(line + "\n"))
		}
	}).Methods(http.MethodGet)

	r.HandleFunc("/v1/schemas/envelope", func(w http.ResponseWriter, r *http.Request) {
		data, _ := os.ReadFile("schemas/envelope.schema.json")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write(data)
	}).Methods(http.MethodGet)

	log.Println("MOVA API listening on :8080")
	log.Fatal(http.ListenAndServe(":8080", r))
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}
